# -*- coding: utf-8 -*-

"""
c_lexer.py
Analizador Léxico (Lexer) para el subconjunto de C.
Usa PLY (Python Lex-Yacc)
"""

import ply.lex as lex

# --- Palabras Reservadas ---
keywords = {
    'if': 'IF',
    'else': 'ELSE',
    'while': 'WHILE', # Lo incluimos aunque el parser aún no lo use
    'for': 'FOR',
    'return': 'RETURN', # Lo incluimos aunque el parser aún no lo use
    'int': 'INT',       # ...
    'float': 'FLOAT',   # ...
    'void': 'VOID',     # ...
    'char': 'CHAR',     # ...
}

# --- Lista de Tokens ---
tokens = [
    'ID',
    'NUMBER',
    'FLOAT_LITERAL',
    'STRING_LITERAL',
    
    # Operadores Aritméticos
    'PLUS', 'MINUS', 'TIMES', 'DIVIDE', 'MODULO',
    
    # Operadores de Asignación
    'EQUALS', 'PLUS_EQUAL', 'MINUS_EQUAL',
    
    # Operadores de Comparación
    'EQ', 'NE', 'LT', 'GT', 'LE', 'GE',
    
    # Delimitadores
    'LPAREN', 'RPAREN',
    'LBRACE', 'RBRACE',
    'LBRACKET', 'RBRACKET',
    'SEMICOLON', 'COMMA',
    
    # Otros
    'INCREMENT', 'DECREMENT',
    'LOGICAL_AND', 'LOGICAL_OR', 'LOGICAL_NOT',
    
] + list(keywords.values())


# --- Definiciones de Tokens (Expresiones Regulares) ---

# Operadores y Delimitadores
t_PLUS = r'\+'
t_MINUS = r'-'
t_TIMES = r'\*'
t_DIVIDE = r'/'
t_MODULO = r'%'
t_EQUALS = r'='
t_PLUS_EQUAL = r'\+='
t_MINUS_EQUAL = r'-='
t_EQ = r'=='
t_NE = r'!='
t_LT = r'<'
t_GT = r'>'
t_LE = r'<='
t_GE = r'>='
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_LBRACE = r'{'
t_RBRACE = r'}'
t_LBRACKET = r'\['
t_RBRACKET = r'\]'
t_SEMICOLON = r';'
t_COMMA = r','
t_INCREMENT = r'\+\+'
t_DECREMENT = r'--'
t_LOGICAL_AND = r'&&'
t_LOGICAL_OR = r'\|\|'
t_LOGICAL_NOT = r'!'

# --- Reglas con Funciones ---

def t_ID(t):
    r'[a-zA-Z_][a-zA-Z0-9_]*'
    t.type = keywords.get(t.value, 'ID')
    return t

def t_FLOAT_LITERAL(t):
    r'\d+\.\d+'
    try:
        t.value = float(t.value)
    except ValueError:
        print("Valor flotante demasiado grande %s" % t.value)
        t.value = 0.0
    return t

def t_NUMBER(t):
    r'\d+'
    try:
        t.value = int(t.value)
    except ValueError:
        print("Valor entero demasiado grande %s" % t.value)
        t.value = 0
    return t

def t_STRING_LITERAL(t):
    r'\"([^\\\"]|\\.)*\"'
    t.value = t.value[1:-1] # Quita las comillas
    return t

# Comentario de bloque (/* ... */)
def t_COMMENT_C89(t):
    r'/\*(.|\n)*?\*/'
    t.lexer.lineno += t.value.count('\n')
    pass

# Comentario de línea (// ...)
def t_COMMENT_C99(t):
    r'//.*'
    pass

# Contar números de línea
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# Ignorar espacios y tabuladores
t_ignore = ' \t'

# Manejo de errores
def t_error(t):
    print("Caracter ilegal '%s' en la línea %d" % (t.value[0], t.lexer.lineno))
    t.lexer.skip(1)

# --- Construcción del Lexer ---
lexer = lex.lex()

# (No incluimos el __main__ de prueba aquí, 
# ya que este archivo está diseñado para ser importado)