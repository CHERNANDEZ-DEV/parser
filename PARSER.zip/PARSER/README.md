# Parser para subconjunto de C

Analizador sintáctico (parser) de descenso recursivo escrito en Python para un subconjunto del lenguaje C. El analizador toma archivos de código fuente como entrada, realiza un análisis léxico y sintáctico, y genera un Árbol de Sintaxis Abstracta (AST) como salida.

## Alcance y limitaciones de la gramática del parser

El parser entiende la **estructura básica de un script** (declaraciones, asignaciones, `if/else`, `for`) y **expresiones aritmético-comparativas**.

Rechazará (con un error de sintaxis) cualquier cosa relacionada con **funciones**, **bucles `while`**, **operadores lógicos (`&&`, `||`)** y **tipos de datos complejos** (como punteros o arreglos).

El parser reconoce y acepta sintácticamente las siguientes estructuras:

### 1. Estructura y Sentencias
* **Bloques de código:** `{ ... }`, incluyendo bloques anidados.
* **Declaraciones de variables:** `int a;`, `float b;`, `char c;`.
* **Inicialización en declaración:** `int a = 10;`.
* **Declaraciones múltiples:** `int a, b = 5, c;`.
* **Asignaciones:** `a = b + 10;`.
* **Punto y coma:** Espera un `;` al final de todas las declaraciones y asignaciones.

### 2. Control de Flujo
* **Condicional `if`:** `if (expresion) { ... }`
* **Condicional `else`:** `... else { ... }`
* **Condicional `else if`:** `... else if (expresion) { ... }`
* **Bucle `for`:** `for (parte_init; parte_cond; parte_update) { ... }`
    * `parte_init`: Acepta una asignación (`i = 0;`) o una declaración (`int i = 0;`).
    * `parte_cond`: Acepta una expresión (`i < 10`).
    * `parte_update`: Acepta una asignación sin punto y coma (`i = i + 1`).

### 3. Expresiones
* **Valores (Factores):**
    * Números (ej: `10`, `10.5`)
    * Identificadores (ej: `mi_variable`)
    * Cadenas de texto (ej: `"Hola"`)
* **Agrupación:** Paréntesis (`(a + b)`).
* **Operadores aritméticos:** `+`, `-`, `*`, `/` (con precedencia `*`/` ` sobre `+`/`-`).
* **Operadores de comparación:** `==`, `!=`, `<`, `>`, `<=`, `>=`.

EL parser **fallará** (lanzará un `SyntaxError`) si encuentra cualquiera de las siguientes estructuras:

### 1. Funciones
* **Definición de funciones:** `void mi_funcion() { ... }` o `int main() { ... }`.
* **Llamadas a función:** `mi_funcion(a);` o `printf("hola");`.
* **Sentencias `return`:** `return 0;`.
* **Tipo `void`:** No lo reconoce como un tipo válido.

### 2. Control de Flujo Faltante
* **Bucles `while`:** `while (a < 10) { ... }`
* **Bucles `do-while`:** `do { ... } while (a);`
* **Switch-Case:** `switch (a) { case 1: ... }`
* **Control de bucles:** `break;` y `continue;`.

### 3. Expresiones Faltantes
* **Operadores lógicos:** `&&` (AND), `||` (OR), `!` (NOT).
* **Operadores de incremento/decremento:** `i++`, `i--`, `++i`, `--i`.
* **Operadores de asignación compuesta:** `a += 1;`, `b *= 2;`.
* **Operador ternario:** `(a > b) ? a : b`.
* **Operadores de bits:** `&`, `|`, `^`, `<<`, `>>`, `~`.

### 4. Tipos de Datos Complejos
* **Punteros:** `int *p;`, `p = &a;`, `*p = 10;`.
* **Arrays (Arreglos):** `int mi_array[10];`, `mi_array[0] = 5;`.
* **Structs, Unions, Enums:** `struct MiTipo { ... };`.
* **Calificadores:** `const`, `static`.

El proyecto está dividido en cuatro módulos principales:
* `c_lexer.py`: Analizador Léxico (Lexer)
* `c_ast.py`: Definiciones de Nodos del Árbol de Sintaxis Abstracta
* `c_parser.py`: Analizador Sintáctico (Parser) de Descenso Recursivo
* `main.py`: Punto de entrada para ejecutar el analizador.

---

## Requerimientos

Para ejecutar este proyecto, solo necesitas:

1.  **Python 3** (se recomienda 3.6 o superior)
2.  **pip** (el gestor de paquetes de Python)
3.  La biblioteca **`ply`**

---

## Instalación

1.  Asegúrate de tener los 4 archivos `.py` y la carpeta `source_code` en el mismo directorio.
2.  Abre una terminal y navega a la carpeta del proyecto.
3.  Instala la dependencia `ply` usando `pip`:

    ```bash
    pip install ply
    ```
    *(Usa `pip3 install ply` si tu sistema lo requiere)*

## Ejecución de tests

El script principal es `main.py`. Debes pasarle como argumentos las rutas a los archivos de prueba que deseas analizar.

### Uso general

Abre tu terminal en la carpeta `PARSER/` y ejecuta:

```bash
python main.py <ruta_al_archivo_1.c> [ruta_al_archivo_2.c] ...
```

Ejemplo: 

```bash
python main.py tests/valid/01_declarations.c
```




