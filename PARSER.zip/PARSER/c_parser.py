# -*- coding: utf-8 -*-
try:
    from c_lexer import lexer
except ImportError:
    print("Error: No se pudo encontrar 'c_lexer.py'.")
    exit(1)

try:
    from c_ast import *
except ImportError:
    print("Error: No se pudo encontrar 'c_ast.py'.")
    exit(1)

EOF = '$'

class RecursiveDescentParser:
    def __init__(self, lexer, verbose=False):
        self.lexer = lexer
        self.tokens_list = []
        self.token_idx = 0
        self.current_token = None
        self.verbose = verbose
        self.indent_level = 0
    
    def _log(self, message):
        if self.verbose:
            indent = "  " * self.indent_level
            print(f"{indent}{message}")

    def _get_all_tokens(self, input_text):
        self.lexer.input(input_text)
        self.tokens_list = []
        
        self._log("--- FASE 1: LEXER ---")
        while True:
            tok = self.lexer.token()
            if not tok:
                break
            self.tokens_list.append(tok)
            if self.verbose:
                self._log(f"  Token: {tok.type} (valor: '{tok.value}')")
        
        class EOFToken: pass
        eof_tok = EOFToken()
        eof_tok.type = EOF
        eof_tok.value = EOF
        eof_tok.lineno = self.lexer.lineno
        self.tokens_list.append(eof_tok)
        
        self.token_idx = 0
        self.current_token = self.tokens_list[0]
        self.lexer.lineno = 1
        self._log("------------------------\n")

    def advance(self):
        """Avanza al siguiente token"""
        self.token_idx += 1
        if self.token_idx < len(self.tokens_list):
            self.current_token = self.tokens_list[self.token_idx]
        else:
            self.current_token = self.tokens_list[-1]

    def eat(self, expected_type):
        """Consume el token actual si es del tipo esperado."""
        if self.current_token.type == expected_type:
            token_comido = self.current_token
            self._log(f"-> Consumiendo Token: '{token_comido.value}' (Tipo: {token_comido.type})")
            self.advance()
            return token_comido
        else:
            raise SyntaxError(
                f"Error de Sintaxis (eat): Se esperaba '{expected_type}' "
                f"pero se encontró '{self.current_token.value}' (tipo {self.current_token.type}) "
                f"en la línea {self.current_token.lineno}"
            )

    # --- Métodos de la Gramática ---

    def parse(self, input_text):
        """Punto de entrada principal. Parsea un programa completo."""
        self._get_all_tokens(input_text)
        
        self._log("--- FASE 2: PARSER (Rastro de Ejecución) ---")
        self.indent_level = 0
        
        programa_ast = Block()
        
        while self.current_token.type != EOF:
            sentencia = self.stmt()
            programa_ast.sentencias.append(sentencia)

        print("\nAnálisis completado: CADENA VÁLIDA.")
        return programa_ast

    def stmt(self):
        """MODIFICADO: stmt -> declaration_stmt | assign_stmt | if_stmt | for_stmt | block_stmt"""
        self._log(f"[stmt] Buscando sentencia (token actual: {self.current_token.type})")
        self.indent_level += 1
        try:
            token_tipo = self.current_token.type
            
            # PREDICCIÓN: Si es un tipo, es una declaración
            if token_tipo in ('INT', 'FLOAT', 'CHAR'):
                nodo = self.declaration_stmt()
            
            elif token_tipo == 'ID':
                nodo = self.assign_stmt()
            elif token_tipo == 'IF':
                nodo = self.if_stmt()
            elif token_tipo == 'FOR':
                nodo = self.for_stmt()
            elif token_tipo == 'LBRACE':
                nodo = self.block_stmt()
            else:
                raise SyntaxError(
                    f"Error de Sintaxis (stmt): Se esperaba el inicio de una sentencia "
                    f"(Tipo, ID, IF, FOR, {{), pero se encontró '{self.current_token.value}'"
                    f" en la línea {self.current_token.lineno}"
                )
        finally:
            self.indent_level -= 1
            self._log(f"[stmt] Saliendo de sentencia")
        return nodo

    def assign_stmt(self):
        """Gramática: assign_stmt -> ID EQUALS expr SEMICOLON"""
        self._log("[assign_stmt] Parseando asignación...")
        self.indent_level += 1
        try:
            id_token = self.eat('ID')
            variable_node = Var(id_token.value)
            self.eat('EQUALS')
            expresion_node = self.expr()
            self.eat('SEMICOLON')
            nodo = Assign(variable_node, expresion_node)
        finally:
            self.indent_level -= 1
            self._log("[assign_stmt] Fin asignación")
        return nodo
        
    def assignment_no_semi(self):
        """Helper para 'for': ID EQUALS expr (SIN punto y coma)"""
        self._log("[assignment_no_semi] Parseando asignación (sin ';')...")
        self.indent_level += 1
        try:
            id_token = self.eat('ID')
            variable_node = Var(id_token.value)
            self.eat('EQUALS')
            expresion_node = self.expr()
            nodo = Assign(variable_node, expresion_node)
        finally:
            self.indent_level -= 1
            self._log("[assignment_no_semi] Fin asignación (sin ';')")
        return nodo

    def if_stmt(self):
        """Gramática: if_stmt -> IF LPAREN expr RPAREN LBRACE block RBRACE 
                                  [ ELSE (LBRACE block RBRACE | if_stmt) ]"""
        self._log("[if_stmt] Parseando 'if'...")
        self.indent_level += 1
        try:
            self.eat('IF')
            self.eat('LPAREN')
            condicion_node = self.expr()
            self.eat('RPAREN')
            
            self.eat('LBRACE')
            bloque_verdadero_node = self.block()
            self.eat('RBRACE')
            
            bloque_falso_node = None
            if self.current_token.type == 'ELSE':
                self._log("[if_stmt] Detectado 'else'")
                self.eat('ELSE')
                if self.current_token.type == 'IF':
                    bloque_falso_node = self.if_stmt() # else if...
                elif self.current_token.type == 'LBRACE':
                    self.eat('LBRACE')
                    bloque_falso_node = self.block()    # else { ... }
                    self.eat('RBRACE')
                else:
                    raise SyntaxError(
                       f"Error de Sintaxis: Se esperaba 'if' o '{{' después de 'else', "
                       f"pero se encontró '{self.current_token.value}'"
                    )
            nodo = IfStatement(condicion_node, bloque_verdadero_node, bloque_falso_node)
        finally:
            self.indent_level -= 1
            self._log("[if_stmt] Fin 'if'")
        return nodo
        
    def for_stmt(self):
        """Gramática: FOR ( [init]; [cond]; [update] ) { block }"""
        self._log("[for_stmt] Parseando 'for'...")
        self.indent_level += 1
        try:
            self.eat('FOR')
            self.eat('LPAREN')
            
            # 1. Init
            init_node = None
            if self.current_token.type != 'SEMICOLON':
                # Puede ser una asignación 'a = 1' o una declaración 'int a = 1'
                if self.current_token.type in ('INT', 'FLOAT', 'CHAR'):
                    init_node = self.declaration_stmt() # declaration_stmt ya come el ';'
                else:
                    init_node = self.assign_stmt() # assign_stmt ya come el ';'
            else:
                self.eat('SEMICOLON')
                
            # 2. Condición
            cond_node = None
            if self.current_token.type != 'SEMICOLON':
                cond_node = self.expr()
            self.eat('SEMICOLON')
            
            # 3. Update
            update_node = None
            if self.current_token.type != 'RPAREN':
                update_node = self.assignment_no_semi()
                
            self.eat('RPAREN')
            
            # 4. Bloque
            self.eat('LBRACE')
            bloque_node = self.block()
            self.eat('RBRACE')
            
            nodo = ForLoop(init_node, cond_node, update_node, bloque_node)
        finally:
            self.indent_level -= 1
            self._log("[for_stmt] Fin 'for'")
        return nodo

    # --- NUEVAS FUNCIONES PARA DECLARACIÓN ---
    
    def type_specifier(self):
        """Gramática: type_specifier -> INT | FLOAT | CHAR"""
        self._log("[type_specifier] Parseando tipo...")
        self.indent_level += 1
        try:
            token = self.current_token
            if token.type == 'INT':
                self.eat('INT')
            elif token.type == 'FLOAT':
                self.eat('FLOAT')
            elif token.type == 'CHAR':
                self.eat('CHAR')
            else:
                raise SyntaxError(f"Error de Sintaxis: Se esperaba un tipo (int, float, char) pero se encontró {token.type}")
            
            nodo = Type(token)
        finally:
            self.indent_level -= 1
            self._log(f"[type_specifier] Fin tipo (valor: {nodo.valor})")
        return nodo

    def var_declaration(self, type_node):
        """Gramática: var_declaration -> ID (EQUALS expr)?"""
        self._log("[var_declaration] Parseando declaración de variable...")
        self.indent_level += 1
        try:
            var_token = self.eat('ID')
            var_node = Var(var_token.value)
            assign_node = None
            
            if self.current_token.type == 'EQUALS':
                self._log("[var_declaration] Detectada inicialización...")
                self.eat('EQUALS')
                expresion_node = self.expr()
                assign_node = Assign(var_node, expresion_node)
            
            nodo = VarDeclaration(var_node, type_node, assign_node)
        finally:
            self.indent_level -= 1
            self._log(f"[var_declaration] Fin declaración (var: {var_node.nombre})")
        return nodo

    def declaration_stmt(self):
        """Gramática: declaration_stmt -> type_specifier var_declaration (COMMA var_declaration)* SEMICOLON"""
        self._log("[declaration_stmt] Parseando sentencia de declaración...")
        self.indent_level += 1
        try:
            type_node = self.type_specifier()
            
            declaraciones = [self.var_declaration(type_node)]
            
            while self.current_token.type == 'COMMA':
                self.eat('COMMA')
                declaraciones.append(self.var_declaration(type_node))
                
            self.eat('SEMICOLON')
            
            # Si solo hay una, devuelve el nodo. Si hay varias, devuélvelas en un bloque.
            if len(declaraciones) == 1:
                nodo = declaraciones[0]
            else:
                nodo = Block()
                nodo.sentencias = declaraciones
        finally:
            self.indent_level -= 1
            self._log("[declaration_stmt] Fin sentencia de declaración")
        return nodo
        
    # --- FIN NUEVAS FUNCIONES ---
        
    def block_stmt(self):
        """Gramática: block_stmt -> LBRACE block RBRACE"""
        self._log("[block_stmt] Parseando bloque {}...")
        self.indent_level += 1
        try:
            self.eat('LBRACE')
            nodo_bloque = self.block()
            self.eat('RBRACE')
        finally:
            self.indent_level -= 1
            self._log("[block_stmt] Fin bloque {}")
        return nodo_bloque

    def block(self):
        """Gramática: block -> (stmt)* (Parsea sentencias DENTRO de un bloque)"""
        self._log("[block] Parseando contenido de bloque...")
        self.indent_level += 1
        bloque_node = Block()
        try:
            while self.current_token.type != 'RBRACE' and self.current_token.type != EOF:
                sentencia = self.stmt()
                bloque_node.sentencias.append(sentencia)
                
            if self.current_token.type == EOF:
                raise SyntaxError("Error de Sintaxis: Se esperaba '}' pero se encontró fin de archivo")
        finally:
            self.indent_level -= 1
            self._log("[block] Fin contenido de bloque")
        return bloque_node

    # --- Métodos de Expresiones (Sin cambios) ---

    def expr(self):
        """Gramática: expr -> comparison"""
        self._log("[expr] Parseando expresión (llama a comparison)...")
        return self.comparison()

    def comparison(self):
        """Gramática: comparison -> arith_expr ( (EQ|NE|LT|GT|LE|GE) arith_expr )*"""
        self._log("[comparison] Parseando expresión de comparación...")
        self.indent_level += 1
        try:
            nodo = self.arith_expr()
            op_comparacion = ['EQ', 'NE', 'LT', 'GT', 'LE', 'GE']
            while self.current_token.type in op_comparacion:
                op_token = self.eat(self.current_token.type)
                nodo_derecha = self.arith_expr()
                nodo = BinOp(nodo, op_token.value, nodo_derecha)
        finally:
            self.indent_level -= 1
            self._log("[comparison] Fin expresión de comparación")
        return nodo

    def arith_expr(self):
        """Gramática: arith_expr -> term ( (PLUS | MINUS) term )*"""
        self._log("[arith_expr] Parseando expresión aritmética (+/-)...")
        self.indent_level += 1
        try:
            nodo = self.term()
            while self.current_token.type in ('PLUS', 'MINUS'):
                op_token = self.eat(self.current_token.type)
                nodo_derecha = self.term()
                nodo = BinOp(nodo, op_token.value, nodo_derecha)
        finally:
            self.indent_level -= 1
            self._log("[arith_expr] Fin expresión aritmética")
        return nodo

    def term(self):
        """Gramática: term -> factor ( (TIMES | DIVIDE) factor )*"""
        self._log("[term] Parseando término (* /)...")
        self.indent_level += 1
        try:
            nodo = self.factor()
            while self.current_token.type in ('TIMES', 'DIVIDE'):
                op_token = self.eat(self.current_token.type)
                nodo_derecha = self.factor()
                nodo = BinOp(nodo, op_token.value, nodo_derecha)
        finally:
            self.indent_level -= 1
            self._log("[term] Fin término")
        return nodo

    def factor(self):
        """
        Gramática: factor -> LPAREN expr RPAREN
                          | ID
                          | NUMBER
                          | STRING_LITERAL
        """
        self._log(f"[factor] Parseando factor (token actual: {self.current_token.type})")
        self.indent_level += 1
        try:
            token = self.current_token
            if token.type == 'LPAREN':
                self.eat('LPAREN')
                nodo_expr = self.expr()
                self.eat('RPAREN')
                nodo = nodo_expr
            elif token.type == 'ID':
                self.eat('ID')
                nodo = Var(token.value)
            elif token.type == 'NUMBER':
                self.eat('NUMBER')
                nodo = Num(token.value)
            elif token.type == 'STRING_LITERAL':
                self.eat('STRING_LITERAL')
                nodo = StringLiteral(token.value)
            else:
                raise SyntaxError(
                    f"Error de Sintaxis (factor): Factor inesperado. "
                    f"Se esperaba '(', ID, NUMBER o STRING, pero se encontró '{token.value}'"
                    f" en la línea {token.lineno}"
                )
        finally:
            self.indent_level -= 1
            self._log("[factor] Fin factor")
        return nodo