// Prueba de bucle 'for'
int i;
for (i = 0; i < 10; i = i + 1) {
    int x = 5;
}

// Prueba 'for' con declaración de inicialización
for (int j = 0; j < 5; j = j + 1) {
    int y = 10;
}