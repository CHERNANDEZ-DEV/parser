// Prueba de if, else, y else-if.
int a = 10;

if (a == 10) {
    a = 1;
}

if (a == 0) {
    a = 2;
} else {
    a = 3;
}

if (a == 1) {
    a = 100;
} else if (a == 3) {
    a = 200;
}