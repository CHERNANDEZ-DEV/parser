// Prueba de integración de todas las características.
int a = 1;
int b = 0;
int i;

for (i = 0; i < 10; i = i + 1) {
    if (a == 1) {
        b = 100;
    } else {
        b = 200;
    }
    a = 0; 
}