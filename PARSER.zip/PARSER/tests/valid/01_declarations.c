// Prueba de declaraciones simples, con inicialización y múltiples.
int a;
float b = 10.5;
char c;

int x, y = 5, z;