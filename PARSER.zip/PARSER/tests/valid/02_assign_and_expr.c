// Prueba de asignaciones, precedencia y comparaciones.
int a, b, c, d;

a = 10;
b = 5 * 2;
c = (a + b) / 4;

// Prueba de strings y comparaciones
if (a > c) {
    d = "mayor";
}