// Error: Falta el punto y coma en la declaración.
int a