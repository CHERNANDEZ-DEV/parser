// Error: Inicialización incorrecta (falta '=').
int a 10;