// Error: Falta el paréntesis de cierre en el 'if'.
int a = 10;
if (a == 10 {
    a = 1;
}