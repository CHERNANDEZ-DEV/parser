# -*- coding: utf-8 -*-

"""
c_ast.py
Define todas las clases de nodos para el Árbol de Sintaxis Abstracta (AST).
"""

# --- Nodos de Sentencias (Statements) ---

class Block:
    """Nodo para un bloque de sentencias: { ... }"""
    def __init__(self):
        self.sentencias = []
    
    def __repr__(self):
        # Imprime cada sentencia en una nueva línea para legibilidad
        sentencias_str = ',\n    '.join(repr(s) for s in self.sentencias)
        return f"Block(\n    {sentencias_str}\n)"

class Assign:
    """Nodo para Asignación: variable = expresion"""
    def __init__(self, variable, expresion):
        self.variable = variable
        self.expresion = expresion

    def __repr__(self):
        return f"Assign(variable={self.variable}, expresion={self.expresion})"

class IfStatement:
    """Nodo para: if (condicion) { ... } else { ... }"""
    def __init__(self, condicion, bloque_verdadero, bloque_falso=None):
        self.condicion = condicion
        self.bloque_verdadero = bloque_verdadero
        self.bloque_falso = bloque_falso
    
    def __repr__(self):
        if self.bloque_falso:
            return f"IfStatement(condicion={self.condicion}, then={self.bloque_verdadero}, else={self.bloque_falso})"
        else:
            return f"IfStatement(condicion={self.condicion}, then={self.bloque_verdadero})"

class ForLoop:
    """Nodo para: for (init; condicion; update) { bloque }"""
    def __init__(self, init, condicion, update, bloque):
        self.init = init
        self.condicion = condicion
        self.update = update
        self.bloque = bloque
    
    def __repr__(self):
        return f"ForLoop(init={self.init}, cond={self.condicion}, update={self.update}, body={self.bloque})"

class VarDeclaration:
    """NUEVO: Nodo para una declaración de variable: int a; o int a = 10;"""
    def __init__(self, var_node, type_node, assign_node=None):
        self.var_node = var_node       # El nodo Var(nombre='a')
        self.type_node = type_node     # El nodo Type(valor='int')
        self.assign_node = assign_node   # None, o el nodo Assign(Var('a'), Num(10))
    
    def __repr__(self):
        if self.assign_node:
            return f"VarDeclaration(var={self.var_node}, type={self.type_node}, init={self.assign_node})"
        else:
            return f"VarDeclaration(var={self.var_node}, type={self.type_node})"


# --- Nodos de Expresiones (Expressions) ---

class BinOp:
    """Nodo para Operación Binaria: izquierda OP derecha"""
    def __init__(self, izquierda, op, derecha):
        self.izquierda = izquierda
        self.op = op
        self.derecha = derecha
    
    def __repr__(self):
        return f"BinOp(izquierda={self.izquierda}, op='{self.op}', derecha={self.derecha})"

class Var:
    """Nodo para un Identificador (Variable)"""
    def __init__(self, nombre):
        self.nombre = nombre
    
    def __repr__(self):
        return f"Var(nombre='{self.nombre}')"

class Num:
    """Nodo para un Número (entero o flotante)"""
    def __init__(self, valor):
        self.valor = valor

    def __repr__(self):
        return f"Num(valor={self.valor})"

class StringLiteral:
    """Nodo para un literal de cadena: "hola" """
    def __init__(self, valor):
        self.valor = valor
    
    def __repr__(self):
        return f'StringLiteral(valor="{self.valor}")'

class Type:
    """NUEVO: Nodo para un tipo de dato: int, float, etc."""
    def __init__(self, token):
        self.token = token
        self.valor = token.value
    
    def __repr__(self):
        return f"Type(valor='{self.valor}')"