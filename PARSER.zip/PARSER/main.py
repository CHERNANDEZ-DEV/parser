# -*- coding: utf-8 -*-

"""
main.py
Punto de entrada principal para probar el parser.

Este archivo:
1. Importa el lexer y el parser.
2. Lee uno o más nombres de archivo desde los argumentos de la línea de comandos.
3. Lee el contenido de esos archivos.
4. Ejecuta el parser sobre ese contenido.
"""

import sys  # Importamos 'sys' para leer los argumentos de la terminal

# Importa la instancia 'lexer' creada por PLY
try:
    from c_lexer import lexer
except ImportError:
    print("Error: No se pudo encontrar 'c_lexer.py'.")
    exit(1)

# Importa la *clase* del parser
try:
    from c_parser import RecursiveDescentParser
except ImportError:
    print("Error: No se pudo encontrar 'c_parser.py'.")
    exit(1)
    

def parse_file(parser, filename):
    """
    Función helper que lee un archivo y ejecuta el parser
    manejando los posibles errores.
    """
    print(f"\n--- Parseando archivo: {filename} ---")
    
    try:
        # Abre el archivo y lee todo su contenido
        with open(filename, 'r') as f:
            data = f.read()
        
        # Pasa el contenido del archivo al parser
        ast_generado = parser.parse(data)
        
        # Esta es la FASE 3: El resultado final
        print(f"\n--- FASE 3: AST Generado para {filename} (¡Éxito!) ---")
        print(ast_generado)

    except FileNotFoundError:
        print(f"\n*** Error: El archivo '{filename}' no se encontró. ***")
    except SyntaxError as e:
        print(f"\n*** Error de Análisis en {filename} ***")
        print(e)
    except Exception as e:
        # Captura cualquier otro error inesperado
        print(f"\n*** Ocurrió un error inesperado con {filename}: {e} ***")


def main():
    """Función principal para ejecutar el análisis."""
    
    # Comprueba si se pasaron archivos como argumentos
    # sys.argv[0] es el nombre del script (ej: "main.py")
    # sys.argv[1] es el primer argumento, y así sucesivamente.
    if len(sys.argv) < 2:
        print("Uso: python main.py <archivo1.c> [archivo2.c] ...")
        print("Ejemplo: python main.py tests/test_valid.c")
        sys.exit(1) # Salir si no hay archivos
        
    # Instanciamos el parser (una sola vez) con modo verbose
    mi_parser = RecursiveDescentParser(lexer, verbose=True)
    
    # Obtenemos la lista de archivos de los argumentos
    filenames = sys.argv[1:]
    
    # Iteramos sobre cada archivo que el usuario nos pasó
    for filename in filenames:
        parse_file(mi_parser, filename)
        print("="*60)

# --- Punto de entrada estándar de Python ---
if __name__ == "__main__":
    main()